import launch
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo, Node
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    return LaunchDescription([
        # Declare necessary launch arguments
        DeclareLaunchArgument('use_sim_time', default_value='false', description='Use simulation time'),

        # Launch the my_service_server node
        Node(
            package='my_service_server',  # Package name where your service server is defined
            executable='my_service_server',  # The node executable name
            name='service_server_node',  # Node name (optional)
            output='screen',  # Output to the console
            parameters=[{'use_sim_time': LaunchConfiguration('use_sim_time')}],
        ),

        # Launch the cpp_node node
        Node(
            package='cpp_package',  # Package where your cpp_node is defined
            executable='cpp_node',  # The node executable name
            name='cpp_node',  # Node name (optional)
            output='screen',  # Output to the console
            parameters=[{'use_sim_time': LaunchConfiguration('use_sim_time')}],
        ),

        # Launch the USB camera node using the camera.launch.py file
        # This assumes usb_cam package provides the camera.launch.py file
        # Make sure the launch file exists and is correct in the usb_cam package
        LogInfo(
            condition=launch.conditions.LaunchConfigurationEquals('use_sim_time', 'true'),
            msg="Using simulation time"
        ),
        Node(
            package='usb_cam',  # USB camera package name
            executable='usb_cam_node',  # This could be 'usb_cam_node' or the correct node executable
            name='usb_cam_node',  # Node name
            output='screen',  # Output to the console
            parameters=[{'use_sim_time': LaunchConfiguration('use_sim_time')}],
        ),
    ])

